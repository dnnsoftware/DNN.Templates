﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Dnn.Modules.$safeprojectname$.Models
{
    public class Settings
    {
        public bool Setting1 { get; set; }
        public DateTime Setting2 { get; set; }
    }
}